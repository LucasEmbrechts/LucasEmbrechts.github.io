<?php
class Calculatrice {
    function diviser($a, $b) {
        if ($b == 0) {
            echo "Erreur : division par zéro !<br>";
            return -1;
        }
        return $a / $b;
    }
}

$calc = new Calculatrice();
$moyenne = $calc->diviser(30, 3);
echo "Moyenne : $moyenne<br>";
$moyenne = $calc->diviser(30, 0);
echo "Moyenne : $moyenne<br>";
$resultat = $calc->diviser(-5, 5);
echo "Résultat : $resultat<br>";
