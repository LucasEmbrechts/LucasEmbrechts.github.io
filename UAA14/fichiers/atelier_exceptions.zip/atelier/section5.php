<?php
class AgeInvalideException extends Exception {}

class Eleve {
    private $nom;
    private $age;
    function __construct($nom, $age) {
        if ($age < 0) {
            throw new AgeInvalideException("Âge invalide pour $nom : $age");
        }
        $this->nom = $nom;
        $this->age = $age;
        echo "$nom est créé<br>";
    }
    function __toString() {
        return "$this->nom ($this->age ans)";
    }
}

$classe = array();
foreach (array(array("Zoé", 16), array("Malik", -3), array("Sam", 17)) as $donnees) {
    try {
        $eleve = new Eleve($donnees[0], $donnees[1]);
        array_push($classe, $eleve);
    } catch (AgeInvalideException $e) {
        echo $e->getMessage() . "<br>";
    }
}
echo count($classe) . " élèves : " . implode(", ", $classe) . "<br>";
