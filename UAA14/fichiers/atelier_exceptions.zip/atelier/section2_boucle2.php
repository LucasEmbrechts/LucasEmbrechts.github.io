<?php
class Calculatrice {
    function diviser($a, $b) {
        if ($b == 0) {
            throw new Exception("Division de $a par zéro");
        }
        return $a / $b;
    }
}

$calc = new Calculatrice();
try {
    foreach (array(5, 0, 2) as $diviseur) {
        echo "100 / $diviseur = " . $calc->diviser(100, $diviseur) . "<br>";
    }
} catch (Exception $e) {
    echo "Impossible : " . $e->getMessage() . "<br>";
}
echo "Fin<br>";
