<?php
class Calculatrice {
    function diviser($a, $b) {
        if ($b == 0) {
            throw new Exception("Division de $a par zéro");
        }
        return $a / $b;
    }
    function moyenne($total, $nombre) {
        return $this->diviser($total, $nombre);
    }
}

class Bulletin {
    private $calc;
    function __construct() {
        $this->calc = new Calculatrice();
    }
    function afficherMoyenne($nom, $total, $nombre) {
        echo "$nom : " . $this->calc->moyenne($total, $nombre) . "<br>";
    }
}

$bulletin = new Bulletin();
try {
    $bulletin->afficherMoyenne("Zoé", 45, 3);
    $bulletin->afficherMoyenne("Malik", 0, 0);
    $bulletin->afficherMoyenne("Sam", 28, 2);
} catch (Exception $e) {
    echo "Problème : " . $e->getMessage() . "<br>";
}
echo "Fin<br>";
