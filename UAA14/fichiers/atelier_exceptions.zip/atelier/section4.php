<?php
class DivisionParZeroException extends Exception {}
class NombreNegatifException extends Exception {}

class Calculatrice {
    function diviser($a, $b) {
        if ($b == 0) {
            throw new DivisionParZeroException("Division de $a par zéro");
        }
        return $a / $b;
    }
    function racine($x) {
        if ($x < 0) {
            throw new NombreNegatifException("Pas de racine carrée pour $x");
        }
        return sqrt($x);
    }
}

$calc = new Calculatrice();
foreach (array(16, -4, 0) as $x) {
    try {
        echo "1 / racine($x) = " . $calc->diviser(1, $calc->racine($x)) . "<br>";
    } catch (DivisionParZeroException $e) {
        echo "Division impossible : " . $e->getMessage() . "<br>";
    } catch (NombreNegatifException $e) {
        echo "Racine impossible : " . $e->getMessage() . "<br>";
    }
}
echo "Fin<br>";
