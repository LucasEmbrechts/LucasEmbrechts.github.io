<?php
class Calculatrice {
    function diviser($a, $b) {
        if ($b == 0) {
            throw new Exception("Division de $a par zéro");
        }
        return $a / $b;
    }
}

$calc = new Calculatrice();
echo "Début<br>";
try {
    echo "A<br>";
    $r = $calc->diviser(30, 0);
    echo "B : $r<br>";
} catch (Exception $e) {
    echo "C : " . $e->getMessage() . "<br>";
}
echo "Fin<br>";
