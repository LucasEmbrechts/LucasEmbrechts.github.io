<?php
class Calculatrice {
    function diviser($a, $b) {
        if ($b == 0) {
            throw new Exception("Division de $a par zéro");
        }
        return $a / $b;
    }
}

$calc = new Calculatrice();
echo "Début<br>";
echo "Résultat : " . $calc->diviser(30, 3) . "<br>";
echo "Résultat : " . $calc->diviser(30, 0) . "<br>";
echo "Fin<br>";
