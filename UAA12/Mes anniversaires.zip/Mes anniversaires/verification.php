<!DOCTYPE <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Formulaire</title>      
    </head>
    <body>
<?php
    echo "<h1>Cher(e) $_POST[name] voici vos futurs anniversaires :</h1>";
?>
<table>
	<tr>
		<th id="colAnnee">Année</th>
        <?php
            if(isset($_POST['dateAnniv']))
            {
                echo "<th id=colDate> Dates d'anniversaire</th>";
            }
            if(isset($_POST['jourAnniv']))
            {
                echo "<th id=colJour>Jours d'anniversaire</th>";
            }
            if(isset($_POST['age']))
            {
                echo "<th id=colAge>Age</th>";
            }
        ?>
    </tr>
    <?php
        for($annee = 2015; $annee <= 2025; $annee++)
        {
            echo "<tr>";
            echo "<td>$annee</td>";
        
            if(isset($_POST['dateAnniv']))
            {
                echo "<td>$_POST[days]/$_POST[months]/ $annee</td>";
            }
            else echo "<td></td>";

            if(isset($_POST['jourAnniv']))
            {
                $date = "$annee/$_POST[months]/$_POST[days]";
                echo "<td>".date("l", strtotime($date))."</td>";
            }

            if(isset($_POST['age']))
            {
                $a = $annee - $_POST['year'];
                echo "<td>$a ans</td>";
            }
            echo "</tr>";
        }

    ?>
</table>
    </body>
</html>