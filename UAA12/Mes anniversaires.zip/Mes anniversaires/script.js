let tabMonths = ["janvier","fevrier","mars","avril","mai","juin","juillet","aout","septembre","octobre","novembre","décembre"];
let liste;
let option;
let wrapper;
//INTERRO ! Éviter les getElementById dans une boucle, préférer le mettre en variable globale
window.onload = function()
{
    liste = document.getElementById("daysList");
    option = document.createElement("option");
    wrapper = document.getElementById("wrapper-months");


    for(let i = 1; i <= 31; i++)
    {
        addOption(i,i);
    }

    let numMois = 1;

    for(let month of tabMonths)
    {
        addInput(month,month.substr(0,4),numMois);
        numMois++;
    }

    checkInput("janv");

    document.getElementById("submitButton").onclick = dateValide;
}

function addOption(name,value)
{
    option.setAttribute("value",value);
    option.innerHTML = name;
    liste.appendChild(option);
}

function addInput(lab,id,value)
{
    let label = document.createElement("label");
    let input = document.createElement("input");

    label.setAttribute("for",id);
    label.innerHTML = lab;

    input.setAttribute("type","radio");
    input.setAttribute("name","months");
    input.setAttribute("id",id);
    input.setAttribute("value",value);
    input.setAttribute("onchange","dateValide()")

    wrapper.appendChild(input);
    wrapper.appendChild(label); 
    wrapper.appendChild(document.createElement("br"));
}

function checkInput(id)
{
    document.getElementById(id).checked = true;
}

function dateValide()
{
    let jour = document.getElementById("daysList").value;
    let mois = getMois().value;
    let année = document.getElementById("year").value;
    if(!anneeValide(année) || !moisValide(année,mois,jour))
    {
        document.getElementById("commentaire").innerHTML = "Cette date n'est pas valide !";
        return false;
    }
    else
    {
        document.getElementById("commentaire").innerHTML = "";
        return true;
    }
}

function getMois()
{
    let inputs = document.getElementsByTagName("input");
    let months = [];
    for(let input of inputs)
    {
        if(input.getAttribute("name") === "months") months.push(input);
    }
    for(let month of months)
    {
        if(month.checked) return month;
    }
    //Utiliser querySelector
}

function anneeValide(année)
{
    return année >= 1910 && année <= 2050;
}

function estBissextile(annee)
{
    return (annee%400 === 0 || (annee%4 === 0 && annee%100 !== 0));
}

function moisValide(annee,mois,jour)
{
    let tabNbDays = [31,29,31,30,31,30,31,31,30,31,30,31]
    if(estBissextile(annee))
    {
        tabNbDays[1] = 28;
    }
    return (jour <= tabNbDays[mois - 1])

}
