#include <stdio.h>

void masquerE(char texte[]);

void main(void) {
    char phrase[] = "Le petit chene";
    masquerE(phrase);
    printf("%s\n", phrase);
}

void masquerE(char texte[]) {
    for (int i = 0; texte[i] != '\0'; i++) {
        if (texte[i] == 'e') {
            texte[i] = '*';
        }
    }
}
