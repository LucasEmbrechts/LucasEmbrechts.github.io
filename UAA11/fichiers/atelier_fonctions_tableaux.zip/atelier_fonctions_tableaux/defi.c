#include <stdio.h>
#define NB_ELEVES 6

void saisirNotes(int notes[], int taille);
float moyenne(int notes[], int taille);
int compterReussites(int notes[], int taille, int seuil);
void ajouterBonus(int notes[], int taille, int bonus);
void afficherNotes(int notes[], int taille);

void main(void) {
    int notes[NB_ELEVES];
    saisirNotes(notes, NB_ELEVES);
    afficherNotes(notes, NB_ELEVES);
    printf("Moyenne : %.2f - Reussites : %d\n", moyenne(notes, NB_ELEVES), compterReussites(notes, NB_ELEVES, 10));
    ajouterBonus(notes, NB_ELEVES, 2);
    afficherNotes(notes, NB_ELEVES);
    printf("Moyenne : %.2f - Reussites : %d\n", moyenne(notes, NB_ELEVES), compterReussites(notes, NB_ELEVES, 10));
}

// À toi d’écrire les cinq fonctions ici.
