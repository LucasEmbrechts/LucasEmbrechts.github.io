#include <stdio.h>

void afficher(int t[], int taille);

void main(void) {
    int scores[5] = {42, 17, 8, 23, 4};
    int bonus[2] = {7, 3};
    afficher(scores, 5);
    afficher(bonus, 2);
}

void afficher(int t[], int taille) {
    for (int i = 0; i < taille; i++) {
        printf("%d ", t[i]);
    }
    printf("\n");
}
