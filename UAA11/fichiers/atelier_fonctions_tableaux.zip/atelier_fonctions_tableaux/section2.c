#include <stdio.h>

void mesurer(int t[]);

void main(void) {
    int scores[5] = {42, 17, 8, 23, 4};
    printf("main    : sizeof = %d\n", sizeof(scores));
    mesurer(scores);
}

void mesurer(int t[]) {
    printf("mesurer : sizeof = %d\n", sizeof(t));
}
