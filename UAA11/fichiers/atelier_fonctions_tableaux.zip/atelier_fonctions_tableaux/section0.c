#include <stdio.h>

void remiseAZero(int n);
void remiseAZeroTableau(int t[]);

void main(void) {
    int score = 42;
    int scores[3] = {42, 17, 8};
    remiseAZero(score);
    remiseAZeroTableau(scores);
    printf("score = %d\n", score);
    printf("scores[0] = %d\n", scores[0]);
}

void remiseAZero(int n) {
    n = 0;
}

void remiseAZeroTableau(int t[]) {
    t[0] = 0;
}
