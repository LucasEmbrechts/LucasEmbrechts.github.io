#include <stdio.h>

void montrer(int n, int t[]);

void main(void) {
    int score = 42;
    int scores[3] = {42, 17, 8};
    printf("main    : score  est a l'adresse %p\n", &score);
    printf("main    : scores est a l'adresse %p\n", scores);
    montrer(score, scores);
}

void montrer(int n, int t[]) {
    printf("montrer : n      est a l'adresse %p\n", &n);
    printf("montrer : t pointe vers l'adresse %p\n", t);
}
