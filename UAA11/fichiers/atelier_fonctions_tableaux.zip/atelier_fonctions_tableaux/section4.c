#include <stdio.h>

int compterE(char texte[]);

void main(void) {
    char phrase[] = "Le petit chene";
    printf("%d\n", compterE("elephant"));
    printf("%d\n", compterE(phrase));
}

int compterE(char texte[]) {
    int n = 0;
    for (int i = 0; texte[i] != '\0'; i++) {
        if (texte[i] == 'e') {
            n++;
        }
    }
    return n;
}
