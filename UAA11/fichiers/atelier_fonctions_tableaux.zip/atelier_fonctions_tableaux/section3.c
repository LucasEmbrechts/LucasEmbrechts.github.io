#include <stdio.h>
#define NB 5

void remplirCarres(int t[], int taille);

void main(void) {
    int carres[NB];
    remplirCarres(carres, NB);
    for (int i = 0; i < NB; i++) {
        printf("%d ", carres[i]);
    }
    printf("\n");
}

void remplirCarres(int t[], int taille) {
    for (int i = 0; i < taille; i++) {
        t[i] = (i + 1) * (i + 1);
    }
}
