#include <stdio.h>

int[] creerCarres(void);

void main(void) {
    int carres[5];
    carres = creerCarres();
}
