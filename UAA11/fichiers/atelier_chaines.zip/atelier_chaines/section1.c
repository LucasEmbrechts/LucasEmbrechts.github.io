#include <stdio.h>
#include <string.h>

void main(void) {
    char mot[] = "Bonjour";
    mot[3] = '\0';
    printf("%s\n", mot);
    printf("strlen : %d / sizeof : %d\n", strlen(mot), sizeof(mot));
    mot[3] = 'j';
    printf("%s\n", mot);
}
