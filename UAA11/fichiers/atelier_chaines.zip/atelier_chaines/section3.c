#include <stdio.h>
#include <string.h>

void main(void) {
    char a[20] = "lune";
    char b[20];
    b = a;
    printf("a : %s / b : %s\n", a, b);
}
