#include <stdio.h>
#include <string.h>

void main(void) {
    char prenom[20] = "Lina";
    char nom[20] = "Martin";
    char complet[40] = "";
    strcat(complet, prenom);
    strcat(complet, nom);
    printf("[%s]\n", complet);
    printf("Longueur : %d\n", strlen(complet));
}
