#include <stdio.h>
#include <string.h>

void main(void) {
    char nom[50];
    printf("Ton nom complet : ");
    scanf("%s", nom);
    getchar();
    printf("Bonjour %s !\n", nom);
    printf("Longueur : %d\n", strlen(nom));
}
