#include <stdio.h>
#include <string.h>

void main(void) {
    char code[8] = "ABC";
    char petit[4];
    strcpy(petit, "123456789");
    printf("petit : %s\n", petit);
    printf("code  : %s\n", code);
}
