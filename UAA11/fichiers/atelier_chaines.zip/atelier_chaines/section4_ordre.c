#include <stdio.h>
#include <string.h>

void main(void) {
    printf("%d\n", strcmp("pomme", "poire"));
    printf("%d\n", strcmp("poire", "pomme"));
    printf("%d\n", strcmp("Pomme", "pomme"));
    printf("%d\n", strcmp("pomme", "pommes"));
}
