#include <stdio.h>
#include <string.h>

void main(void) {
    char a[20] = "pomme";
    char b[20] = "pomme";
    if (a == b) {
        printf("avec == : identiques\n");
    } else {
        printf("avec == : differentes\n");
    }
    if (strcmp(a, b) == 0) {
        printf("avec strcmp : identiques\n");
    } else {
        printf("avec strcmp : differentes\n");
    }
}
