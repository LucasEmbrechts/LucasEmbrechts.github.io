#include <stdio.h>
#include <string.h>

void main(void) {
    char ville[] = "Namur";
    for (int i = 0; i < 6; i++) {
        printf("case %d : code %d\n", i, ville[i]);
    }
    printf("sizeof : %d\n", sizeof(ville));
    printf("strlen : %d\n", strlen(ville));
}
