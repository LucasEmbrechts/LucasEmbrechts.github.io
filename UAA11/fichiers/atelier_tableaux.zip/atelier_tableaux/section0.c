#include <stdio.h>

void main(void) {
    int note1 = 12, note2 = 15, note3 = 9, note4 = 17, note5 = 11;
    int total = note1 + note2 + note3 + note4 + note5;
    printf("Moyenne : %.2f\n", (float) total / 5);
}
