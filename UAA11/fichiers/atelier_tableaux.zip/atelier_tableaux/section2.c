#include <stdio.h>

void main(void) {
    int resultats[5];
    for (int i = 0; i < 5; i++) {
        printf("%d ", resultats[i]);
    }
    printf("\n");
}
