#include <stdio.h>

void main(void) {
    int notes[5] = {12, 15, 9, 17, 11};
    printf("%d\n", notes[1]);
    printf("%d\n", notes[0] + notes[4]);
    notes[2] = 10;
    for (int i = 0; i < 5; i++) {
        printf("notes[%d] = %d\n", i, notes[i]);
    }
}
