#include <stdio.h>

void main(void) {
    int original[4] = {3, 1, 4, 1};
    int copie[4];
    copie = original;
    printf("%d\n", copie[0]);
}
