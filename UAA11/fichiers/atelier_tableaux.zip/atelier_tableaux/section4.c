#include <stdio.h>
#define NB_NOTES 5

void main(void) {
    int notes[NB_NOTES];
    for (int i = 0; i < NB_NOTES; i++) {
        printf("Note %d : ", i + 1);
        scanf("%d", &notes[i]);
        getchar();
    }
    int total = 0;
    for (int i = 0; i < NB_NOTES; i++) {
        total = total + notes[i];
    }
    float moyenne = (float) total / NB_NOTES;
    printf("Moyenne : %.2f\n", moyenne);
    printf("Au-dessus de la moyenne :");
    for (int i = 0; i < NB_NOTES; i++) {
        if (notes[i] > moyenne) {
            printf(" %d", notes[i]);
        }
    }
    printf("\n");
}
