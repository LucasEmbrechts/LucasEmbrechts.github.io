#include <stdio.h>

void main(void) {
    double prix[] = {2.5, 3.0, 1.2};
    printf("%d\n", sizeof(prix));
    printf("%d\n", sizeof(double));
    printf("%d\n", sizeof(prix) / sizeof(double));
}
