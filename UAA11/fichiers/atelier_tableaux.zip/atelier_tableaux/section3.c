#include <stdio.h>

void main(void) {
    int notes[] = {12, 15, 9, 17, 11, 14};
    printf("%d\n", sizeof(notes));
    printf("%d\n", sizeof(int));
    printf("%d\n", sizeof(notes) / sizeof(int));
}
