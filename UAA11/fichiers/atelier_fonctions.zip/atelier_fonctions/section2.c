#include <stdio.h>

int carre(int x);

void main(void) {
    int a = carre(4);
    printf("%d\n", a);
    printf("%d\n", carre(3) + carre(2));
    carre(5);
    printf("%d\n", carre(carre(2)));
}

int carre(int x) {
    return x * x;
}
