#include <stdio.h>

void main(void) {
    int age;
    printf("Age : ");
    scanf("%d", &age);
    getchar();
    while (age < 0 || age > 120) {
        printf("Age invalide. Age : ");
        scanf("%d", &age);
        getchar();
    }
    float prix;
    if (age < 12) {
        prix = 2.50;
    } else if (age < 65) {
        prix = 4.00;
    } else {
        prix = 3.00;
    }
    printf("----------------\n");
    printf("Entree piscine\n");
    printf("Age  : %d ans\n", age);
    printf("Prix : %.2f euros\n", prix);
    printf("----------------\n");
}
