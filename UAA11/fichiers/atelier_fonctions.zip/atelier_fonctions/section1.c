#include <stdio.h>

void afficherLigne(void) {
    for (int i = 0; i < 10; i++) printf("*");
    printf("\n");
}

void main(void) {
    afficherLigne();
    printf("  MENU DU JOUR\n");
    afficherLigne();
    printf("  Soupe : 2.50\n");
    printf("  Plat  : 8.00\n");
    afficherLigne();
}
