#include <stdio.h>
#include <stdbool.h>

bool estPair(int n);

void main(void) {
    for (int i = 1; i <= 6; i++) {
        if (estPair(i)) {
            printf("%d est pair\n", i);
        }
    }
    printf("%d\n", estPair(7));
}

bool estPair(int n) {
    if (n % 2 == 0) {
        return true;
    } else {
        return false;
    }
}
