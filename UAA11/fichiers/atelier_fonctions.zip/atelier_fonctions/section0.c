#include <stdio.h>

void main(void) {
    for (int i = 0; i < 10; i++) printf("*");
    printf("\n");
    printf("  MENU DU JOUR\n");
    for (int i = 0; i < 10; i++) printf("*");
    printf("\n");
    printf("  Soupe : 2.50\n");
    printf("  Plat  : 8.00\n");
    for (int i = 0; i < 10; i++) printf("*");
    printf("\n");
}
