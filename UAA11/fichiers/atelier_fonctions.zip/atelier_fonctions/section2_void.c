#include <stdio.h>

void afficherCarre(int x);

void main(void) {
    int a = afficherCarre(4);
    printf("%d\n", a);
}

void afficherCarre(int x) {
    printf("%d\n", x * x);
}
