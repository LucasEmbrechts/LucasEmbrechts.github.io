#include <stdio.h>

void afficherLigne(int longueur);

void main(void) {
    afficherLigne(20);
    printf("  MENU DU JOUR\n");
    afficherLigne(20);
    printf("  Soupe : 2.50\n");
    printf("  Plat  : 8.00\n");
    afficherLigne(5);
}

void afficherLigne(int longueur) {
    for (int i = 0; i < longueur; i++) printf("*");
    printf("\n");
}
