#include <stdio.h>

void main(void) {
    int i = 50;
    for (int i = 0; i < 3; i++) {
        printf("%d ", i);
    }
    printf("%d\n", i);
}
