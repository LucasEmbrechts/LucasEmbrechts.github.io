#include <stdio.h>

void doubler(int n);

void main(void) {
    int prix = 10;
    doubler(prix);
    printf("prix = %d\n", prix);
}

void doubler(int n) {
    n = n * 2;
    printf("dans doubler : n = %d\n", n);
}
