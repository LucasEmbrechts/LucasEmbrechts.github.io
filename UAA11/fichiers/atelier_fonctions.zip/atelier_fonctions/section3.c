#include <stdio.h>

void f(void);

void main(void) {
    int compteur = 5;
    f();
    printf("main : compteur = %d\n", compteur);
}

void f(void) {
    int compteur = 100;
    printf("f : compteur = %d\n", compteur);
}
