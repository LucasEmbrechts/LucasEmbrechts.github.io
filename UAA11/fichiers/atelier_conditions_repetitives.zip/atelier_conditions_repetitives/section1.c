#include <stdio.h>

void main(void) {
    int temperature = 35;
    if (18 <= temperature <= 25) {
        printf("Agreable\n");
    } else {
        printf("Pas agreable\n");
    }
}
