#include <stdio.h>

void main(void) {
    int points = 85;
    if (points >= 50) {
        printf("Bronze\n");
    } else if (points >= 70) {
        printf("Argent\n");
    } else if (points >= 80) {
        printf("Or\n");
    }
}
