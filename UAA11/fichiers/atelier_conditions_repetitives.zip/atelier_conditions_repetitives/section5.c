#include <stdio.h>

void main(void) {
    int note;
    int somme = 0;
    int nb = 0;
    printf("Note (-1 pour finir) : ");
    scanf("%d", &note);
    getchar();
    while (note != -1) {
        somme += note;
        nb++;
        printf("Note (-1 pour finir) : ");
        scanf("%d", &note);
        getchar();
    }
    printf("%d notes, moyenne %.2f\n", nb, (float) somme / nb);
}
