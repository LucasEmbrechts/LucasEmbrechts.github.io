#include <stdio.h>

void main(void) {
    int note;
    int somme = 0;
    int nb = 0;
    do {
        printf("Note (-1 pour finir) : ");
        scanf("%d", &note);
        getchar();
        if (note != -1) {
            somme += note;
            nb++;
        }
    } while (note != -1);
    printf("%d notes, moyenne %.2f\n", nb, (float) somme / nb);
}
