#include <stdio.h>

void main(void) {
    for (int ligne = 1; ligne <= 4; ligne++) {
        for (int col = 1; col <= ligne; col++) {
            printf("*");
        }
        printf("\n");
    }
}
