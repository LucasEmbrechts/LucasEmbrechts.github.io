#include <stdio.h>

void main(void) {
    int i = 0;
    while (i < 3) {
        printf("while %d\n", i);
        i++;
    }
    printf("apres le while, i = %d\n", i);
    for (int j = 1; j <= 3; j++) {
        printf("for %d\n", j);
    }
    int k = 10;
    do {
        printf("do %d\n", k);
        k++;
    } while (k < 3);
}
