#include <stdio.h>

void main(void) {
    for (int j = 1; j <= 3; j++) {
        printf("for %d\n", j);
    }

    int n = 20;
    int etapes = 0;
    while (n > 1) {
        n = n / 2;
        etapes++;
    }
    printf("while : %d etapes, n = %d\n", etapes, n);

    char reponse;
    do {
        printf("Encore un tour ? (o/n) : ");
        scanf("%c", &reponse);
        getchar();
    } while (reponse == 'o');
    printf("fin\n");
}
