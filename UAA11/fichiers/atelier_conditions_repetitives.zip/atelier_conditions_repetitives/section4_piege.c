#include <stdio.h>

void main(void) {
    for (int j = 1; j <= 3; j++);
    {
        printf("tour\n");
    }
}
