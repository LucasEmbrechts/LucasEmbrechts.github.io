#include <stdio.h>

void main(void) {
    int note = 9;
    if (note >= 10) {
        printf("Reussi\n");
    } else {
        printf("Echec\n");
    }
    if (note = 10) {
        printf("Note parfaite ?\n");
    }
    printf("note vaut maintenant %d\n", note);
}
