#include <stdio.h>

void main(void) {
    int age;
    do {
        printf("Age (0 a 120) : ");
        scanf("%d", &age);
        getchar();
    } while (age < 0 || age > 120);
    printf("Age accepte : %d\n", age);
}
