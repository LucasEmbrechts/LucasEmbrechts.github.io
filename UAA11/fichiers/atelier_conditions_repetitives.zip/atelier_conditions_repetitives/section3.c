#include <stdio.h>

void main(void) {
    int choix = 2;
    switch (choix) {
        case 1:
            printf("Nouvelle partie\n");
        case 2:
            printf("Charger\n");
        case 3:
            printf("Options\n");
            break;
        default:
            printf("Choix inconnu\n");
    }
}
