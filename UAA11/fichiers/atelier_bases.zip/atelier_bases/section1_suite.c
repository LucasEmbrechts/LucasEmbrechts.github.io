#include <stdio.h>

void main(void) {
    int nbPlaces = 9.99;
    printf("Places : %d\n", nbPlaces);
    printf("|%6.2f|%-6d|%04d|\n", 3.14159, 42, 7);
}
