#include <stdio.h>

void main(void) {
    int bonbons = 17;
    int enfants = 0;
    printf("Chacun recoit %d bonbons\n", bonbons / enfants);
    printf("Fin\n");
}
