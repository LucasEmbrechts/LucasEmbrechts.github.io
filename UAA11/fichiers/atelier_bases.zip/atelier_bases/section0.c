#include <stdio.h>

void main(void) {
    printf("Bonjour");
    printf("tout le monde");
    printf("\n");
    printf("Il a dit \"salut\" et 50 %% de la classe a ri.\n");
}
