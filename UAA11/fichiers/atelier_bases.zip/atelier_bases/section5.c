#include <stdio.h>

void main(void) {
    char lettre = 'C';
    printf("%c %d\n", lettre, lettre);
    printf("%c\n", lettre + 1);
    printf("%d\n", lettre + 1);
    printf("%c\n", lettre + 32);
    char chiffre = '7';
    printf("%d\n", chiffre - '0');
}
