#include <stdio.h>

void main(void) {
    int annee;
    printf("Ton annee de naissance : ");
    scanf("%d", &annee);
    getchar();
    printf("En 2026, tu auras %d ans.\n", 2026 - annee);
}
