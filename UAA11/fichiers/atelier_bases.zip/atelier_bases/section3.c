#include <stdio.h>

void main(void) {
    int bonbons = 17;
    int enfants = 5;
    printf("%d\n", bonbons / enfants);
    printf("%d\n", bonbons % enfants);
    float part = bonbons / enfants;
    printf("%.2f\n", part);
    part = (float) bonbons / enfants;
    printf("%.2f\n", part);
}
