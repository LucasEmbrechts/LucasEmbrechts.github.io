#include <stdio.h>

void main(void) {
    int quantite;
    char taille;
    printf("Quantite : ");
    scanf("%d", &quantite);
    printf("Taille (S, M ou L) : ");
    scanf("%c", &taille);
    printf("Commande : %d x taille [%c]\n", quantite, taille);
}
