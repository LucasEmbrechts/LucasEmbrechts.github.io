#include <stdio.h>
#include <stdbool.h>

void main(void) {
    int age = 17;
    float taille = 1.75;
    char initiale = 'L';
    bool inscrit = true;
    printf("Age : %d ans\n", age);
    printf("Taille : %f m\n", taille);
    printf("Taille : %.2f m\n", taille);
    printf("Initiale : %c\n", initiale);
    printf("Inscrit : %d\n", inscrit);
}
