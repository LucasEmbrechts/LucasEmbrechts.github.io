#include <stdio.h>

void main(void) {
    int minutes = 125;
    printf("%d h %02d\n", minutes / 60, minutes % 60);
}
