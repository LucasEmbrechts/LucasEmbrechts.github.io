#include <stdio.h>

void main(void) {
    int n = 5;
    int a = n++;
    int b = ++n;
    printf("a = %d, b = %d, n = %d\n", a, b, n);
    n = 10;
    n += 3;
    n *= 2;
    printf("n = %d\n", n);
}
