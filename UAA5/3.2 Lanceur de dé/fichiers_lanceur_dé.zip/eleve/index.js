const buttonEl = document.getElementById("roll-button");
const diceEl = document.getElementById("dice");
const rollHistoryEl = document.getElementById("roll-history");

function rollDice() {
    // à copmpléter
}

function lancer(){
    diceEl.classList.add("roll-animation");
    setTimeout(() => {
        diceEl.classList.remove("roll-animation");
        rollDice();
    }, 1000);
}


// Code des différents dés :
// 1: "&#9856;"
// 2: "&#9857;"
// 3: "&#9858;"
// 4: "&#9859;"
// 5: "&#9860;"
// 6: "&#9861;"