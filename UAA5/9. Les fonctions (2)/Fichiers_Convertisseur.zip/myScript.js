function convert(cyan, magenta, jaune, noir){
	
}